#include "stm32f10x.h"

#include "motor.h"

int main (void)
{
	
    TIM2_PWM_Init(1999,719);
    while(1)
    {
      
        //-90��
		   TIM_SetCompare1(TIM2,1750);//ռ�ձȣ�2000-1750��/2000*20ms=2.5ms
    }

	

}